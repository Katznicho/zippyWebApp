<?php

return [
    "property_staus" => [
        "Vacant" => "Vacant",
        "Occupied" => "Occupied",
        "Under Construction" => "Under Construction",
        "Rented" => "Rented"
    ]
];
