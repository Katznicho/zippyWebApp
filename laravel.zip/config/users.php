<?php
return [
'Roles' => [
    'Admin' => "Admin",
    'User' =>"User",
    "Agent"=>"Agent",
    "Property Owner"=>"Property Owner"
]
];