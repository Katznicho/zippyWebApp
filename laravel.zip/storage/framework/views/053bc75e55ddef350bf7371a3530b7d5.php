<?php echo e($slot); ?>

<?php /**PATH /home/codeartisan/Desktop/laravelapps/zippy/resources/views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>