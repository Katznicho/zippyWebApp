<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php
    $record = $this->getRecord();
    $images = $record->images ?? [];
    $coverImage = $record->cover_image ?? null;
    ?>

    <div class="container mx-auto">
        <h1 class="text-3xl font-bold mb-4">Images</h1>

        <div class="mb-8">
            <!--[if BLOCK]><![endif]--><?php if($coverImage): ?>
            <h2 class="text-lg font-bold mb-2">Cover Image</h2>
            <div class="flex items-center justify-center mb-4">
                <img src="<?php echo e($coverImage); ?>" alt="Cover Image" class="cursor-pointer max-w-full rounded-lg transition-transform hover:scale-110 cursor-zoom-in">
            </div>
            <hr class="mb-4 border-t border-gray-300">
            <?php else: ?>
            <p>No cover image available.</p>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </div>

        <div>
            <!--[if BLOCK]><![endif]--><?php if($images): ?>
            <h2 class="text-lg font-bold mb-2">Other Images</h2>
            <div class="flex flex-wrap gap-4">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e($image); ?>" alt="Image" class="cursor-pointer max-w-[calc(25%-1rem)] mb-4 rounded-md transition-transform hover:scale-110">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
            <?php else: ?>
            <p>No images available.</p>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?><?php /**PATH /home/codeartisan/Desktop/laravelapps/zippy/resources/views/filament/resources/property-resource/pages/view-images.blade.php ENDPATH**/ ?>