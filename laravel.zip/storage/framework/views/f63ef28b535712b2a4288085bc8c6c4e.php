[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/codeartisan/Desktop/laravelapps/zippy/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>